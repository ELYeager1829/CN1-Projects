// Show location alert on page load
window.onload = function() {
    alert("Reminder: Make sure your location services are enabled.");
};

// Hover effect for navigation links
const navLinks = document.querySelectorAll("nav ul li a");
navLinks.forEach(link => {
    link.addEventListener("mouseenter", function() {
        link.style.color = "#ffffff"; // Change to white on hover
        link.style.backgroundColor = "#007bff"; // Add background color on hover
        link.style.transition = "background-color 0.3s ease, color 0.3s ease"; // Smooth hover effect
    });
    link.addEventListener("mouseleave", function() {
        link.style.color = "#b0b0b0"; // Revert to original color
        link.style.backgroundColor = "transparent"; // Remove background
    });
});

// Navigation functions for each page
function goToHomePage() {
    window.location.href = "index.html";
}

function goToEventsPage() {
    window.location.href = "events.html";
}

function goToUploadPage() {
    window.location.href = "upload.html";
}

function goToContactPage() {
    window.location.href = "contact.html";
}

function goToProfilePage() {
    window.location.href = "profile.html";
}

// Adding event listeners to navigation links
document.getElementById('home-link').addEventListener('click', goToHomePage);
document.getElementById('events-link').addEventListener('click', goToEventsPage);
document.getElementById('upload-link').addEventListener('click', goToUploadPage);
document.getElementById('contact-link').addEventListener('click', goToContactPage);
document.getElementById('profile-link').addEventListener('click', goToProfilePage);
