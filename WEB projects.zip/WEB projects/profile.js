// Profile form validation
const profileForm = document.getElementById('profile-form');

profileForm.addEventListener('submit', function(event) {
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    if (username === '' || email === '' || password === '') {
        alert('Please fill out all fields.');
        event.preventDefault(); // Prevent form submission
    } else {
        alert('Profile updated successfully!'); // Dummy success message
    }
});
