function initMap() {
    // Set the center of the map to a specific location
    var myCenter = { lat: -25.363, lng: 131.044 }; // Example coordinates (replace with your desired location)

    // Create a map object
    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 10, // Zoom level
        center: myCenter // Center the map to myCenter
    });

    // Create a marker with animation
    var marker = new google.maps.Marker({
        position: myCenter,
        animation: google.maps.Animation.BOUNCE // Bounce animation
    });

    // Set the marker on the map
    marker.setMap(map);
}
