// Message submission for police contact
const contactForm = document.getElementById('contact-form');

contactForm.addEventListener('submit', function(event) {
    const message = document.getElementById('message').value;

    if (message.trim() === '') {
        alert('Please type a message before submitting.');
        event.preventDefault(); // Prevent form submission
    } else {
        alert('Your message has been sent to the police.'); // Dummy success message
    }
});
