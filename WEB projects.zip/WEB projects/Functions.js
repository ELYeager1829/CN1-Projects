// Show location alert on page load
window.onload = function() {
    alert("Reminder: Make sure your location services are enabled.");
};

// Login form validation
const loginForm = document.getElementById('login-form');
loginForm.addEventListener('submit', function(event) {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (username === '' || password === '') {
        alert('Please fill in both username and password.');
        event.preventDefault(); // Prevent form submission
    } else {
        alert('Login successful!'); // Dummy success message
    }
});

// File upload functionality
const fileUpload = document.getElementById('file-upload');
const fileNameDisplay = document.getElementById('file-name');
const uploadForm = document.getElementById('upload-form');

fileUpload.addEventListener('change', function() {
    const file = fileUpload.files[0];
    if (file) {
        fileNameDisplay.textContent = `Selected file: ${file.name}`;
    } else {
        fileNameDisplay.textContent = '';
    }
});

uploadForm.addEventListener('submit', function(event) {
    if (!fileUpload.files.length) {
        alert('Please select a file to upload.');
        event.preventDefault(); // Prevent form submission
    } else {
        alert('File uploaded successfully!'); // Dummy success message
    }
});
